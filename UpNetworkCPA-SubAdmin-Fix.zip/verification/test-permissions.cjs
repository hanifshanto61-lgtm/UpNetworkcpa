const fs = require("node:fs");
const path = require("node:path");
const assert = require("node:assert/strict");
const { stripTypeScriptTypes } = require("node:module");

function compile(source, exports, dependencies = {}) {
  const plain = stripTypeScriptTypes(source)
    .replace(/^import\s+[\s\S]*?;\s*/gm, "")
    .replace(/\bexport\s+/g, "");
  return new Function(...Object.keys(dependencies), plain + "\nreturn {" + exports.join(",") + "};")(...Object.values(dependencies));
}
const root = path.resolve(__dirname, "..");
let passed = 0;
function check(condition) { assert.ok(condition); passed++; }
async function main() {
  process.env.NEXT_PUBLIC_SUPABASE_URL = "https://test.example";
  process.env.SUPABASE_SERVICE_ROLE_KEY = "test-only";
  let fixture;
  const roleClient = {
    auth: { getUser: async () => ({ data: { user: fixture.user }, error: fixture.authError }) },
    from: () => ({
      select() { return this; }, eq() { return this; },
      maybeSingle: async () => ({ data: fixture.admin, error: fixture.roleError }),
    }),
  };
  const auth = compile(fs.readFileSync(path.resolve(__dirname, "original/lib/admin-auth.ts"), "utf8"), ["getAdminSession", "getSuperAdminSession"], { createClient: () => roleClient });
  const request = { headers: new Headers({ authorization: "Bearer test-token" }) };
  for (const role of ["super_admin", "sub_admin"]) {
    fixture = { user: { id: "u1", email: "another@example.com" }, admin: { role, is_active: true } };
    check((await auth.getAdminSession(request))?.role === role);
    check(Boolean(await auth.getSuperAdminSession(request)) === (role === "super_admin"));
  }
  for (const admin of [null, { role: "affiliate", is_active: true }, { role: "sub_admin", is_active: false }]) {
    fixture = { user: { id: "u1" }, admin };
    check(await auth.getAdminSession(request) === null);
  }
  fixture = { user: null, admin: { role: "sub_admin", is_active: true } };
  check(await auth.getAdminSession(request) === null);
  check(await auth.getAdminSession({ headers: new Headers() }) === null);
  fixture = { user: { id: "u1" }, admin: { role: "sub_admin", is_active: true }, roleError: new Error("db") };
  check(await auth.getAdminSession(request) === null);

  let session = null;
  let businessCalls = 0;
  const client = { from() { businessCalls++; throw Error("Business query reached"); } };
  const response = { json: (body, options = {}) => ({ body, status: options.status ?? 200 }) };
  const deps = {
    NextResponse: response,
    getAdminSession: async () => session,
    createClient: () => client,
    randomBytes: () => Buffer.from("test"),
    console: { error() {}, log() {} },
  };
  const names = ["networks", "networks/secret", "smart-links", "smart-links/postback", "conversions", "statistics", "earnings", "referrals", "payments"];
  for (const name of names) {
    const filename = path.join(root, "app/api/admin", name, "route.ts");
    const source = fs.readFileSync(filename, "utf8");
    check(!source.includes("ADMIN_EMAIL"));
    const helper = ["smart-links", "conversions"].includes(name) ? "verifyAdmin" : "authorize";
    const reports = ["statistics", "earnings", "referrals"].includes(name);
    const handlers = [...source.matchAll(/export async function (GET|POST|PATCH|DELETE)\(/g)].map(m => m[1]);
    const module = compile(source, [...handlers, ...(reports ? [] : [helper])], deps);
    session = null;
    for (const handler of handlers) {
      businessCalls = 0;
      const result = await module[handler](request);
      check([401, 403].includes(result.status));
      check(businessCalls === 0);
    }
    for (const role of ["super_admin", "sub_admin"]) {
      session = { role, client, userId: "u1" };
      if (!reports) {
        const accepted = await module[helper](request);
        check(helper === "verifyAdmin" ? accepted === true : Boolean(accepted));
        if (name === "payments") check(accepted.token === "test-token" && accepted.client === client);
        else if (helper === "authorize") check(accepted === client);
      } else {
        businessCalls = 0;
        await module.GET({ ...request, nextUrl: new URL("https://test.example/api") });
        check(businessCalls === 1);
      }
    }
  }
  let fetchResult;
  let observed;
  const access = compile(fs.readFileSync(path.join(root, "lib/admin-access.ts"), "utf8"), ["verifyAdminAccess"], {
    fetch: async (url, options) => { observed = { url, options }; return fetchResult; },
  });
  for (const role of ["super_admin", "sub_admin", "affiliate", undefined]) {
    fetchResult = { ok: true, json: async () => ({ success: true, admin: { role } }) };
    check(await access.verifyAdminAccess("token") === ["super_admin", "sub_admin"].includes(role));
  }
  fetchResult = { ok: false };
  check(await access.verifyAdminAccess("token") === false);
  check(observed.url === "/api/admin/me" && observed.options.cache === "no-store");
  check(observed.options.headers.Authorization === "Bearer token");
  for (const name of ["affiliates", "smart-links", "conversions", "statistics", "earnings", "referrals", "payments"]) {
    const source = fs.readFileSync(path.join(root, "app/admin", name, "page.tsx"), "utf8");
    check(!source.includes("ADMIN_EMAIL"));
    check(source.includes("await verifyAdminAccess("));
    // Parse the exact changed condition separately; JSX outside it is unchanged.
    const match = source.match(/if \(\s*([\s\S]*?verifyAdminAccess[\s\S]*?)\) \{/);
    if (match) {
      const condition = match[1].slice(match[1].lastIndexOf("if (") + 4);
    }
  }
  const adminsSource = fs.readFileSync(path.resolve(__dirname, "original/app/api/admin/admins/route.ts"), "utf8");
  check([...adminsSource.matchAll(/await getSuperAdminSession\(request\)/g)].length === 3);
  const affiliatesSource = fs.readFileSync(path.resolve(__dirname, "original/app/api/admin/affiliates/route.ts"), "utf8");
  check(affiliatesSource.includes("Admin accounts cannot be modified through the Affiliate API."));
  console.log(passed + " authorization checks passed");
}
main().catch(error => { console.error(error); process.exitCode = 1; });

