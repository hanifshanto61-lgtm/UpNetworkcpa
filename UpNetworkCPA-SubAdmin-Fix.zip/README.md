# UpNetwork CPA admin permissions

Prepared from the current GitHub main files on 2026-10-12.

This package contains complete replacements for 16 files and one new file,
lib/admin-access.ts. Active super_admin and sub_admin accounts use the same
operational permissions. Admin Management continues to use the existing
getSuperAdminSession checks.

## Install

Extract the ZIP. Upload only its app and lib folders into the repository root,
preserving the folder paths, then commit. Alternatively, apply the included
sub-admin-access.patch from a local repository with git apply --check first.
If existing files have changed since this package was prepared, review the
patch against those changes before replacing the files.

Wait for Vercel to report Ready. Sign in as a sub-admin and check Affiliates,
Offers, Networks, Smart Links, Conversions, Statistics, Earnings, Referrals,
Payments, and Feature Settings. Admin Management must remain inaccessible.

## Payment approval: database check still required

The payments API calls public.admin_update_payment_status with the verified
admin JWT. The repository does not contain this function's definition.
Its existing comment describes a main-admin-email check, so API changes
alone may not enable sub-admin payment approval. Run the included read-only
SQL in Supabase SQL Editor and provide its result before changing this function.
No database function or data has been changed by this package.

## Validation

102 authorization assertions passed with mocked authentication/database responses
under Node 24. Tests cover both active roles, inactive admins, affiliates, missing
or invalid authentication, all edited API routes' denial paths, the browser role
helper, and the existing Admin Management and affiliate-account protections.
API TypeScript syntax was parsed during these tests. UI authentication guards
were reviewed; their existing JSX design was preserved.

A full Next.js build, real Supabase operations, and live deployment tests have
not been run. GitHub rejected branch creation with HTTP 403, so no branch,
commit, PR, or deployment was created.
