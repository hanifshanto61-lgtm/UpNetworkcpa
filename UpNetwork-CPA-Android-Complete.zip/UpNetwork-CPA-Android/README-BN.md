# UpNetwork CPA Android App

এটি Android WebView shell app। এটি আপনার চালু UpNetwork CPA ওয়েব প্যানেলকে অ্যাপের ভিতরে খুলবে; আলাদা database, login system বা tracking তৈরি করে না।

## বর্তমান সেটআপ
- App: UpNetwork CPA
- Application ID: `com.upnetworkcpa.app`
- Start URL: `https://upnetworkcpa-worker.hanifshanto61.workers.dev/`
- Build: Android Gradle Plugin 8.7.3, Gradle 8.9, Java 17, Android SDK 35

## APK তৈরি করার সহজ পদ্ধতি (GitHub Actions)
1. ZIP extract করুন।
2. GitHub-এ আপনার repository `hanifshanto61-lgtm/UpNetworkcpa` খুলুন।
3. `main` branch-এ সরাসরি না দিয়ে নতুন branch তৈরি করুন: `android-app`.
4. এই ZIP-এর ভিতরের ফাইলগুলো `android-app` branch-এর root-এ upload/commit করুন।
5. `android-app` branch-এ ফাইলগুলো commit/push করার পর GitHub-এর Actions tab খুলুন।
6. `Build UpNetwork CPA APK` নামে workflow run শুরু হবে। এটি না হলে Actions enable আছে কি না দেখুন।
7. Build সফল হলে workflow run খুলে Artifacts থেকে `UpNetwork-CPA-Android-APK` ZIP download করুন।
8. Artifact ZIP extract করে `app-debug.apk` Android ফোনে install করুন।

## গুরুত্বপূর্ণ
- এই app বর্তমান website-কে দেখায়। Website-এ যে role-based page/access কাজ করে, app-এও সেটিই থাকবে।
- Affiliate-দের আলাদা ডেটা দেখানো এবং Admin-এর সব ডেটা দেখানোর নিরাপত্তা ওয়েব অ্যাপের Supabase Auth, server authorization এবং RLS-এর ওপর নির্ভর করে। এই Android project কোনো permission bypass করে না।
- APK install করার আগে শুধু নিজের GitHub Actions build artifact ব্যবহার করুন।
- Release/Play Store প্রকাশের আগে production signing keystore, privacy policy, app icon artwork এবং বাস্তব device QA প্রয়োজন।
- Google/Firebase push notifications এখানে configure করা হয়নি; notification page/web notifications website যতটুকু দেয়, ততটুকুই পাওয়া যাবে।
- এই project build/debug starter; successful CI build ও live account tests ছাড়া একে production-verified বলা যাবে না।

## Website URL পরিবর্তন করতে
`app/src/main/java/com/upnetworkcpa/app/MainActivity.java` ফাইলে `HOME_URL` constant পরিবর্তন করুন। Allowed host list-এ নতুন host যোগ না করলে নতুন domain app-এর ভিতরে থাকবে না।
